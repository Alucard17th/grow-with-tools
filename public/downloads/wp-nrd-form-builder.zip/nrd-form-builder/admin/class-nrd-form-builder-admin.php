<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://github.com/Alucard17th
 * @since      1.0.0
 *
 * @package    Nrd_Form_Builder
 * @subpackage Nrd_Form_Builder/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Nrd_Form_Builder
 * @subpackage Nrd_Form_Builder/admin
 * @author     Noureddine Eddallal <eddallal.noureddine@gmail.com>
 */
class Nrd_Form_Builder_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Nrd_Form_Builder_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Nrd_Form_Builder_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/nrd-form-builder-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Nrd_Form_Builder_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Nrd_Form_Builder_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/nrd-form-builder-admin.js', array( 'jquery' ), $this->version, false );

		// FORM BUILDER
		wp_enqueue_script( $this->plugin_name.'-form-builder', 'https://cdnjs.cloudflare.com/ajax/libs/jQuery-formBuilder/3.19.7/form-builder.min.js', array( 'jquery' ), '3.19.7', true );
		wp_enqueue_script( $this->plugin_name.'-form-render', 'https://cdnjs.cloudflare.com/ajax/libs/jQuery-formBuilder/3.19.7/form-render.min.js', array( 'jquery' ), '3.19.7', true );
			
		wp_localize_script( $this->plugin_name, 'nrdFormBD', array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'nrd_form_bd_admin' ),
		) );

	}

	// Function to add the menu and the page
	function custom_dashboard_menu() 
	{
		add_menu_page(
			'NRD Form BD',          // Page title
			'NRD Form BD',                // Menu title
			'manage_options',             // Capability
			'nrd-form-bd-menu-slug',           // Menu slug
			array($this, 'custom_dashboard_page_html'), // Function to display the page content
			'dashicons-forms',    // Icon URL or dashicons class
			20                            // Position in the menu
		);
	}

	public function custom_dashboard_page_html() 
	{
		if (!current_user_can('manage_options')) {
			return;
		}
		?>
		<div class="nrd-dashboard-container">
			<!-- Header Section -->
			<header class="nrd-dashboard-header">
				<div>
					<img src="<?php echo plugins_url('images/nrd-logo.png', __FILE__); ?>" alt="wp-nrd-form-builder">
				</div>
				<p class="nrd-dashboard-subtitle">Activate your license key to get started and explore powerful features.</p>
			</header>

			<!-- Main Content -->
			<div class="nrd-dashboard-content">
				<!-- Second Row: Image and Description (Text on Left, Image on Right) -->
				<div class="nrd-second-row">
					<div class="nrd-text-description">
						<h3>Getting Started</h3>
						<p>Watch this tutorial to understand how to activate and use NRD Form Builder. Learn how to build, customize, and manage your forms with ease. Whether you're a beginner or an advanced user, the NRD Form Builder provides powerful tools for creating forms in minutes.</p>
					</div>
					<div class="nrd-image-section">
						<img src="<?php echo plugins_url('images/nrd-form-builder.png', __FILE__); ?>" alt="Form Builder Image">
					</div>
				</div>

				<div class="nrd-third-row">
					<p>Connect with us:</p>
					<div class="nrd-social-icons">
						<a href="https://www.facebook.com/nrdformbuilder/" target="_blank"><img src="<?php echo plugins_url('images/socials/facebook.svg', __FILE__); ?>" alt="Facebook"></a>
						<a href="https://www.instagram.com/nrdformbuilder/" target="_blank"><img src="<?php echo plugins_url('images/socials/instagram.svg', __FILE__); ?>" alt="Instagram"></a>
						<a href="https://www.linkedin.com/company/nrdformbuilder/" target="_blank"><img src="<?php echo plugins_url('images/socials/linkedin.svg', __FILE__); ?>" alt="LinkedIn"></a>
						<a href="https://twitter.com/nrdformbuilder" target="_blank"><img src="<?php echo plugins_url('images/socials/twitter.svg', __FILE__); ?>" alt="Twitter"></a>
						<a href="https://github.com/nrdformbuilder" target="_blank"><img src="<?php echo plugins_url('images/socials/github.svg', __FILE__); ?>" alt="GitHub"></a>
					</div>
				</div>
			</div>

			<!-- Footer Section -->
			<footer class="nrd-dashboard-footer">
				<p>&copy; <?php echo date("Y"); ?> NRD Form Builder. All Rights Reserved.</p>
			</footer>
		</div>
		<?php
	}
	
	public function register_cpt_nrd_form_bd() 
	{
		$labels = array(
			'name' => 'NRD BD Forms',
			'singular_name' => 'NRD BD Form',
			'menu_name' => 'NRD BD Forms',
			'name_admin_bar' => 'NRD BD Form',
			'add_new' => 'Add New',
			'add_new_item' => 'Add New NRD BD Form',
			'new_item' => 'New NRD BD Form',
			'edit_item' => 'Edit NRD BD Form',
			'view_item' => 'View NRD BD Form',
			'all_items' => 'All NRD BD Form',
			'search_items' => 'Search NRD BD Form',
			'parent_item_colon' => 'Parent NRD BD Form:',
			'not_found' => 'No NRD BD Form found.',
			'not_found_in_trash' => 'No NRD BD Form found in Trash.'
		);

		$args = array(
			'labels' => $labels,
			'public' => true,
			'publicly_queryable' => true,
			'show_ui' => true,
			'show_in_menu' => true,
			'query_var' => true,
			'rewrite' => array('slug' => 'nrd-form-bd'),
			'capability_type' => 'post',
			'has_archive' => true,
			'hierarchical' => false,
			'menu_position' => null,
			'supports' => array('title')
		);

		register_post_type('nrd-form-bd', $args);
	}

	public function add_custom_meta_box() 
	{
		add_meta_box(
			'nrd_form_bd_meta_box',          // Unique ID
			'From Builder',         // Box title
			array($this, 'custom_meta_box_html'),  // Content callback, must be of type callable
			'nrd-form-bd',                    // Post type
			'normal',                         // Context
		);
	}

	public function custom_meta_box_html($post) 
	{
		// wp_nonce_field('nrd_form_bd_meta_box', 'nrd_form_bd_meta_box_nonce');
		$screen = get_current_screen();
		$content = $post->post_content;
		if($content != ''){
			$json_content = json_encode($content);
			echo '<script>
				let formData = JSON.parse(' . $json_content . ');
				console.log(formData);
			</script>';
		}

		if ($screen->base == 'post' && isset($_GET['action']) && $_GET['action'] == 'edit') {
			$post_id = isset($_GET['post']) ? intval($_GET['post']) : 0;

			echo '<input type="hidden" name="post_id" id="post_id" value="' . $post_id . '">';
			echo '<div id="short-code-preview">Short Code: 
			<code class="nrd-short-code">[nrd_form_bd id="' . $post_id . '"]</code>
			<span class="nrd-short-code-copy" style="display: none; color: #7F8184;">Link copied to clipboard.</span>
			</div>';
		}
		echo '<div class="wrap">';
		echo '<div id="fb-editor"></div>';
		echo '</div>';
	}

	public function hide_publish_box() 
	{
		remove_meta_box('submitdiv', 'nrd-form-bd', 'side');
	}

	public function disable_autosave_for_nrd_form_bd( $pagehook ) 
	{
		global $post_type, $current_screen;
		if($post_type == 'nrd-form-bd' ){
			wp_deregister_script( 'autosave' );
		}
	}
	
	public function save_nrd_wp_fb() {
		// Security
		check_ajax_referer( 'nrd_form_bd_admin', 'nonce' );
		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( 'Unauthorized', 403 );
		}

		$post_id  = isset($_POST['post_id']) ? absint($_POST['post_id']) : 0;
		$title    = isset($_POST['title']) ? sanitize_text_field( wp_unslash($_POST['title']) ) : '';
		$content  = isset($_POST['content']) ? wp_unslash($_POST['content']) : ''; // JSON string from formBuilder

		// Basic validation
		if ( $title === '' ) {
			wp_send_json_error( 'Title is required', 400 );
		}

		if ( ! $post_id ) {
			$new_post = array(
				'post_title'   => $title,
				'post_content' => wp_slash( $content ), // store raw JSON safely
				'post_type'    => 'nrd-form-bd',
				'post_status'  => 'publish',
			);

			$post_id = wp_insert_post( $new_post, true );
			if ( is_wp_error( $post_id ) ) {
				wp_send_json_error( 'Error: ' . $post_id->get_error_message(), 500 );
			}
		} else {
			$update_post = array(
				'ID'           => $post_id,
				'post_title'   => $title,
				'post_content' => wp_slash( $content ),
			);

			$updated = wp_update_post( $update_post, true );
			if ( is_wp_error( $updated ) ) {
				wp_send_json_error( 'Error: ' . $updated->get_error_message(), 500 );
			}
		}

		wp_send_json_success( html_entity_decode( get_edit_post_link( $post_id ) ) );
	}
}
