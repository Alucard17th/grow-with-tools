(function ($) {
  "use strict";
  $(window).load(function () {
    jQuery(function ($) {
      const nrdActivateLicenserAPIUrl =
        "http://127.0.0.1:8000/api/activate-license";
      const nrdDeactivateLicenserAPIUrl =
        "http://127.0.0.1:8000/api/deactivate-license";

      // Guard + helper
      if (typeof nrdFormBD === "undefined" || !nrdFormBD.nonce) {
        console.warn("NRD Form Builder: missing localized nonce");
      }
      const withNonce = (data = {}) =>
        Object.assign({}, data, { nonce: nrdFormBD.nonce });

      var $fbEditor = $(document.getElementById("fb-editor")),
        $formContainer = $(document.getElementById("fb-rendered-form")),
        fbOptions = {
          onSave: function () {
            let saveBtn = $(".save-template");
            // $fbEditor.toggle();
            // $formContainer.toggle();
            $("form", $formContainer).formRender({
              formData: formBuilder.formData,
            });
            var postIdInput = document.getElementById("post_id");
            var postId = postIdInput ? postIdInput.value : null;
            console.log(formBuilder.formData, postId);
            saveNrdFb(formBuilder.formData, postId, saveBtn);
            // make the clicked save button disabled
          },
        };

      // Check if formData is defined
      if (typeof formData !== "undefined") {
        // Add formData to fbOptions
        fbOptions.formData = formData;
      }

      var formBuilder = $fbEditor.formBuilder(fbOptions);

      $(".edit-form", $formContainer).click(function () {
        $fbEditor.toggle();
        $formContainer.toggle();
      });

      function saveNrdFb(data, postID, saveBtn) {
        saveBtn.prop("disabled", true);
        saveBtn.text("Saving...");
        let title = document.getElementById("title").value;
     
        if (title == "") {
          title = "Untitled Form";
        }

        $.ajax({
          data: withNonce({
            action: "save_nrd_wp_fb",
            title: title,
            content: data,
            post_id: postID,
          }),
          type: "post",
          url: ajaxurl,
          success: function (data) {
            console.log(data.data); //should print out the name since you sent it along
            let editUrl = data.data;
            window.location.href = editUrl;
          },
          error: function (jqXHR, textStatus, errorThrown) {
            console.log(errorThrown);
          },
        });
      }

      $(".nrd-short-code").click(function () {
        const postID = $("#post_id").val();
        const customerLink = '[nrd_form_bd id="' + postID + '"]';
        navigator.clipboard.writeText(customerLink);
        $(".nrd-short-code-copy").show();
        // hide the copy button after 3 seconds
        setTimeout(function () {
          $(".nrd-short-code-copy").hide();
        }, 1500);
      });

      // copy clicked item
      $(".copiable-item").click(function () {
        let element = $(this);
        // Create a temporary textarea element to hold the text to be copied
        const tempInput = document.createElement("textarea");
        // Get the text content of the clicked element using jQuery's .text() method
        tempInput.value = element.text();
        // Append the textarea element to the document
        document.body.appendChild(tempInput);
        // Select the text in the textarea
        tempInput.select();
        // Copy the selected text to the clipboard
        document.execCommand("copy");
        // Remove the temporary textarea element
        document.body.removeChild(tempInput);

        // Optional: You can provide feedback to the user
        alert("Copied to clipboard: " + tempInput.value);
      });
    });
  });
})(jQuery);
